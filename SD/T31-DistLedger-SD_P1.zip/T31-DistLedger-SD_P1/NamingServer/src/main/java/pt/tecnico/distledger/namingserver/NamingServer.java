package pt.tecnico.distledger.namingserver;

public class NamingServer {

    public static void main(String[] args) {

        /* TODO */

    }

}
